Aviral Sinha
CS 344
Program 3: smallsh.c 

Assignment Details: Write a shell in C that will run command 
line instructions and return results similar to previously used shells. 
Shell will support exit, cd and status and comments on lines using # in the beginning.


COMPILING INSTRUCTIONS

Use the provided makefile by typing the commands in the following order:

1. make 
2. ./smallsh
